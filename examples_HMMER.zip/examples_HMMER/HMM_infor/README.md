#The category to be extracted should be consistent with the file names in the label folder. The generated data by HMMER was laid in the data folder. 
#Take the porA for example,the score can be set to defined value,such as 200.
python3 HMM_info.py porA ./label ./data porA_results 200
