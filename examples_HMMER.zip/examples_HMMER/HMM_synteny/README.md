#The results generated in the previous step are placed in the extracted_hmmer_results folder. The operation code is as follows：
python HMM_synteny.py extracted_hmmer_results/6406_porA.txt porA_synteny.txt
