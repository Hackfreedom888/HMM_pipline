#Protein sequence extraction, take porA as an example：
python3 HMM_seq.py  -i protein -f all_porA_out.txt -s species -o result_protein_porA

#Nucleotide sequence extraction, take porA as an example：
python3 HMM_seq.py  -i cds -f all_porA_out.txt -s species -o result_cds_porA