#Genome annotation by gutSMASH
for i in `less list.txt`
do
	python3  run_gutsmash.py --cb-knownclusters --enable-genefunctions  genomes/${i}.fna  --output-dir  gutSMASH_annotation/results_$i  --genefinding-tool  prodigal  -c  16
done

#Sequences extraction
python3 Gut_extractor.py -n porA -i gutSMASH_annotation -o porA_extraction
